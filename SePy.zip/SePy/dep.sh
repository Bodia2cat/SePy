apt install python3

echo [+]start
echo ------
echo ----
echo ---
echo --
echo -

pip3 install colorama
apt install w3m

echo [+]Sucsessful

clear

python3 search2.py